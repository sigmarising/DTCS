﻿//#include "Public_Define.h"

#include "DB_ACCESS.h"

DB_ACCESS &db_access = DB_ACCESS::get_Instance();
int g_season = SEASON_SUMMER;
